import cv2
import numpy as np

def run_file(save_in_file=0):
    ''' save_in_file : 1, If you want to save a output video file,
        anything else otherwise
    '''
    input_file = 'input_video.avi'
    cap = cv2.VideoCapture(input_file)
    ret, frm = cap.read()

    frm_fringed = frm[60:-60, :, :]

    if save_in_file ==1:
        output_file = 'out_figure.mp4'
        fourcc = cv2.VideoWriter_fourcc(*'mp4v') # or *'XVID' for avi
        writer = cv2.VideoWriter(output_file, fourcc, 20.0, (frm_fringed.shape[1], frm_fringed.shape[0]))


    frm_fringed = frm[60:-60,:,:] # pri etom frm_fringed i frm ssylayutsya na te zhe samie yachejki, perepisyvaniya ne proisxodit

    key = ord(' ')
    count_frm = 0

    while(ret==True):
        frm_fringed = frm[60:-60, :, :]

        frm_gauss = cv2.GaussianBlur(frm_fringed, (5,5), 0)
        # frm_median = cv2.medianBlur(frm_fringed, 3)
        # frm_bilateral = cv2.bilateralFilter(frm_fringed, 5, 75, 75)

        frm_hsv = cv2.cvtColor(frm_gauss, cv2.COLOR_BGR2HSV)


        # red mask
        lower_red_hsv = np.array([157, 51, 149], np.uint8)
        upper_red_hsv = np.array([179, 255, 255], np.uint8)

        maskRed = cv2.inRange(frm_hsv, lower_red_hsv, upper_red_hsv)
        maskRed = cv2.morphologyEx(maskRed, cv2.MORPH_OPEN, kernel =  (250,250) )

        #findContours on red mask
        _, conts, _ = cv2.findContours(maskRed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for cnt in conts:
            cv2.drawContours(frm_fringed, [cnt], -1, (0, 0, 255), 3)
            # find the center of the object
            M = cv2.moments(cnt)
            if M['m00']!=0:
                cX = int(M['m10'] / M['m00'])
                cY = int(M['m01'] / M['m00'])

                length = cv2.arcLength(cnt, True)
                area = M['m00']
                koef = length**2 / area

                #determine shift where to put Text
                shX=0
                shY=0
                if (cX<30):
                    shX = +1
                elif (frm_fringed.shape[1]-cX<30):
                    shX = -1
                if (cY<30):
                    shY=+1
                elif (frm_fringed.shape[0]-cY<30):
                    shY = -1
                # determine type of figure
                figure=None
                if(koef<=17):
                    figure = 'circle'
                elif(koef>=19):
                    figure = 'triangle'
                if (figure!=None):
                    sizeofText = 2
                    if area < 2000:
                        sizeofText = 1
                    cv2.putText(frm_fringed, figure, (cX+50*shX, cY+50*shY), 0, sizeofText, [0, 0, 255], 5)


        #
        #
        #
        # green mask
        h, s, v = cv2.split(frm_hsv)
        s_eq = cv2.equalizeHist(s)
        frm_hsv_eq = cv2.merge((h,s_eq,v))
        lower_green_hsv = np.array([22, 101, 116], np.uint8)
        upper_green_hsv = np.array([84, 255, 255], np.uint8)
        maskGreen = cv2.inRange(frm_hsv_eq, lower_green_hsv, upper_green_hsv)
        #findContours on green mask
        _, conts, _ = cv2.findContours(maskGreen, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        # draw only big contours
        for cont in conts:
            area = cv2.contourArea(cont)
            length = cv2.arcLength(cont, True)
            #find the center
            M = cv2.moments(cont)
            if M['m00']!=0:
                cX = int(M['m10'] / M['m00'])
                cY = int(M['m01'] / M['m00'])
                if area>1000:
                    koef = length ** 2 / area
                    # discard the contours with too high value of koef -- it is a noise
                    if koef<30:
                        #find position to put Text (which direction to shift)
                        if cX<frm_fringed.shape[1]/2:
                            shX=+1
                        else:
                            shX=-1
                        if cY<frm_fringed.shape[0]/2:
                            shY=+1
                        else:
                            shY=-1

                        #determine the kind of figure
                        figure = None
                        if koef<=16:
                            figure = 'circle'
                        elif koef<=19.5:
                            figure = 'square'
                        elif koef>=20.5:
                            figure = 'triangle'

                        # cv2.putText(frm_fringed, str(round(area,0)), (cX,cY), 0, 1, (0, 255, 0), 3)
                        # cv2.putText(frm_fringed, str(len(cont)), (cX+shX*10, cY+shY*20), 0, 1, (0, 0, 0), 3 )
                        # cv2.putText(frm_fringed, str(round(koef,1)), (cX + shX*20, cY + shY*50), 0, 1, (255, 0, 0), 3)
                        if figure!=None:
                            cv2.putText(frm_fringed, figure, (cX, cY), 0, 1, (0, 255, 0), 5)
                        cv2.drawContours(frm_fringed, [cont], -1, (0, 255, 0), 3)
            # if area>1000 and :
            #     cv2.drawContours(frm_fringed, [cont], -1, (0, 255, 0), 3)

        # cv2.drawContours(frm_fringed, conts, -1, (0, 255, 0), 3)


        #printing
        cv2.putText(frm_fringed, 'frame: '+str(count_frm), (10,100), 0, 2, [255, 255, 255], 5)
        cv2.imshow('maskRed', maskRed)
        cv2.imshow('maskGreen', maskGreen)
        cv2.imshow('original', frm_fringed)

        # saving in file
        if save_in_file == 1:
            writer.write(frm_fringed)


        if key==ord(' '):
            wait_period = 0
        elif key==27:
            break
        else:
            wait_period=30
        key = cv2.waitKey(wait_period)

        ret, frm = cap.read()
        count_frm +=1


    cap.release()
    writer.release()
    cv2.waitKey(0)

def split_in_3ch(frm):
    out = np.zeros((frm.shape[0], frm.shape[1] * frm.shape[2]), np.uint8)
    for i in range(frm.shape[2]):
        out[:, i * frm.shape[1] : (i + 1) * frm.shape[1]] = frm[:, :, i]
    return out


if __name__ == '__main__':
    run_file(1)

